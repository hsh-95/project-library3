import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import axios from 'axios'
import mintUi from 'mint-ui'
import Myheader from './components/header'
import Myfooter from './components/footer'
import qs from 'qs'

axios.defaults.baseURL = 'http://127.0.0.1:9000'
Vue.prototype.axios = axios;

Vue.prototype.qs = qs;

Vue.use(mintUi);
import 'mint-ui/lib/style.min.css';

Vue.component('my-header',Myheader)
Vue.component('my-footer',Myfooter)


Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
