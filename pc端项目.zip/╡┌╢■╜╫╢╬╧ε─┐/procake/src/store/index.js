import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'
import qs from 'qs'
import router from '../router'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    islogin:localStorage.getItem('islogin') ? localStorage.getItem('islogin') : 0,
    uname:localStorage.getItem('uname') ? localStorage.getItem('uname') : ''
  },
  mutations: {
    logined(state,payload){
      state.islogin = 1;
      state.uname = payload.uname;
      localStorage.setItem('uname',payload.uname)
    },
    logout(state){
      state.islogin = 0;
      state.uname = '';
      localStorage.removeItem('islogin');
      localStorage.removeItem('uname')
    }
  },
  actions: {
    login(context,payload){
      // console.log(payload.uname);
      axios.post('/res_user_login',qs.stringify(payload)).then(results=>{
        console.log(results.data);
        if(results.data.code == 1){
          context.commit('logined',results.data.results)
            router.push('/');
            localStorage.setItem('islogin','1');
            alert('登录成功')
            console.log(results.uname);
        }else{
            alert('用户名或者密码错误！');
        }
    })
    }
  },
  modules: {
  }
})
