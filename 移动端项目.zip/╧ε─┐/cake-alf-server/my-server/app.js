const express = require('express');
const server = express();
const cors = require('cors');
var bodyParser = require('body-parser');
const mysql = require('mysql');
const { parse } = require('path');
const md5 = require('md5');
const pool = mysql.createPool({
    host:'127.0.0.1',
    port:3306,
    user:'root',
    password:'root',
    database:'cake_alf',
    connectionLimit:20
})
server.use(bodyParser.urlencoded({ extended: false }));

// //解决跨域
server.use(cors({
    origin:['http://127.0.0.1:8080','http://localhost:8080']
}));


// 电话号码登陆接口
server.post('/login',(req,res)=>{
    let phone = req.body.phone;
    let upwd = md5(req.body.upwd);
    console.log(phone)
    console.log(upwd)
    let sql = 'select * from cake_alf_user where phone=? AND upwd=?';
    pool.query(sql,[phone,upwd],(err,results)=>{
        if(err)throw err;
        console.log(results)
        // res.send({results});
        if(results.length > 0){
            res.send({message:'success',code:1,info:results[0]});
        }else{
            res.send({message:'error',code:0});
        }
    });
});

server.post('/register',(req,res)=>{
    //接收用户以POST方式提交的数据
    let phone = req.body.phone; 
    let upwd = req.body.upwd;
    let sql = 'SELECT * FROM cake_alf_user WHERE phone=?';
    
    pool.query(sql,[phone],(error,results)=>{
      if(error) throw error;
      if(results.length > 0){
        //产生合理的错误信息到客户端
        res.send({message:'注册失败',code:0});
        return;
      } else {
        //将相关的信息写入到xzqa_author数据表
        sql = 'INSERT cake_alf_user(phone,upwd) VALUES(?,MD5(?))';
        pool.query(sql,[phone,upwd],(error,result)=>{
          if(error) throw error;
          if(result.affectedRows == 1){
            res.send({message: '注册成功',code:1});
          }else{
            res.send({message:'注册失败',code:0});
          }
        });``
      }
    });  
  });

//轮播图接口
server.get("/carousel",(req,res)=>{
	var sql = "select * from cake_alf_carousel";
	pool.query(sql,(err,results)=>{
        if(err) throw err;
        res.send({results})
	})
})

//商品列表接口
server.get("/product",(req,res)=>{
  let id = req.query.family_id;
  let num = /^[0-9]$/;
  if(num.test(id) && id){
	  var sql = "select * from cake_alf_product where family_id=?";
	  pool.query(sql,[id],(err,result)=>{
        if(err) throw err;
        res.send(result)
    })
  }else if(!num.test(id) && id){
	  var sql = `SELECT * FROM cake_alf_product where title like '%${id}%'`;
	  pool.query(sql,[id],(err,result)=>{
        if(err) throw err;
        res.send(result)
    })
  }else{
    var sql = `SELECT * FROM cake_alf_product`;
	  pool.query(sql,(err,result)=>{
        if(err) throw err;
        res.send(result)
    })
  }
})
  


//详情页接口
server.get("/details",(req,res)=>{
  let id = req.query.pid;
	var sql = "select * from cake_alf_details where pid=?";
	pool.query(sql,[id],(err,result)=>{
        if(err) throw err;
        res.send(result)
	})
})




















// //详情页接口
// server.get('/article',(req,res)=>{
//     //获取文章ID
//     let id = req.query.id;
  
    
//     let sql = 'SELECT * FROM cake_alf_details WHERE lid=?';
//     //执行SQL语句
//     pool.query(sql,[id],(err,results)=>{
//       if(err) throw err;
//       console.log(results)
//       res.send({results});
//     });
//   });

// //列表页接口
// server.get('/list',(req,res)=>{
//     let sql = 'SELECT * FROM cake_alf_details';
//     console.log(111)
//     //执行SQL语句
//     pool.query(sql,(err,results)=>{
//       if(err) throw err;
//       console.log(results)
//       res.send({results});
//     });
//   }); 

server.listen(9000,()=>{
    console.log('server is running...')
});