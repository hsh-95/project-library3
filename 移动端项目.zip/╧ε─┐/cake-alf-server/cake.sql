
SET NAMES UTF8;

DROP DATABASE IF EXISTS cake_alf;

CREATE DATABASE cake_alf CHARSET=UTF8;

USE cake_alf;


DROP TABLE IF EXISTS `cake_alf_user`;
CREATE TABLE `cake_alf_user` (
  `uid` int(11) NOT NULL auto_increment,
  `phone` varchar(16) default NULL,
  `upwd` varchar(32) default NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cake_alf_user
-- ----------------------------
INSERT INTO `cake_alf_user` VALUES ('1','13511011000','123456');
INSERT INTO `cake_alf_user` VALUES ('2','13501234568', '123456');



DROP TABLE IF EXISTS `cake_alf_carousel`;
CREATE TABLE `cake_alf_carousel` (
  `cid` int(11) NOT NULL auto_increment,
  `img` varchar(128) default NULL,
  `title` varchar(64) default NULL,
  `href` varchar(128) default NULL,
  PRIMARY KEY  (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cake_alf_carousel
-- ----------------------------
INSERT INTO `cake_alf_carousel` VALUES ('1', 'banner1.jpg', '轮播广告商品1', 'product_details.html?lid=28');
INSERT INTO `cake_alf_carousel` VALUES ('2', 'banner2.jpg', '轮播广告商品2', 'product_details.html?lid=19');

-- ----------------------------
-- Table structure for `cake_alf_product`
-- ----------------------------
DROP TABLE IF EXISTS `cake_alf_product`;
CREATE TABLE `cake_alf_product` (
  `pid` int(11) NOT NULL auto_increment,
  `family_id` int(11) default NULL,
  `title` varchar(64) default NULL,
  `price` decimal(10,2) default NULL, 
	`pic` varchar(128) default NULL,
  PRIMARY KEY  (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cake_alf_product
-- ----------------------------
INSERT INTO `cake_alf_product` VALUES ('1','1', '奥利奥蛋糕','279.00','1.jpg');
INSERT INTO `cake_alf_product` VALUES ('2','1', '小马宝莉联名款生日蛋糕','279.00','2.jpg');
INSERT INTO `cake_alf_product` VALUES ('3','1', 'RIO联名款生日蛋糕','269.00','3.jpg');
INSERT INTO `cake_alf_product` VALUES ('4','1', '小马宝莉联名蛋糕','269.00','4.jpg');
INSERT INTO `cake_alf_product` VALUES ('5','1', '多肉葡萄蛋糕','269.00','5.jpg');
INSERT INTO `cake_alf_product` VALUES ('6','1', '多肉葡萄蛋糕-萄气乐园','279.00','6.jpg');
INSERT INTO `cake_alf_product` VALUES ('7','2', '浪漫甜心','229.00','7.jpg');
INSERT INTO `cake_alf_product` VALUES ('8','2', '玫瑰物语','229.00','8.jpg');
INSERT INTO `cake_alf_product` VALUES ('9','2', '玫瑰花园','229.00','9.jpg');
INSERT INTO `cake_alf_product` VALUES ('10','2', '臻爱礼盒','239.00','10.jpg');
INSERT INTO `cake_alf_product` VALUES ('11','2', '爱的告白','229.00','11.jpg');
INSERT INTO `cake_alf_product` VALUES ('12','2', '特殊补缴款','1.00','12.jpg');
INSERT INTO `cake_alf_product` VALUES ('13','3', '欢乐牧场','299.00','13.jpg');
INSERT INTO `cake_alf_product` VALUES ('14','3', '甜蜜小家','299.00','14.jpg');
INSERT INTO `cake_alf_product` VALUES ('15','3', '天真烂漫','299.00','15.jpg');
INSERT INTO `cake_alf_product` VALUES ('16','3', '快乐成长','199.00','16.jpg');
INSERT INTO `cake_alf_product` VALUES ('17','3', '欢乐童年','199.00','17.jpg');
INSERT INTO `cake_alf_product` VALUES ('18','3', '童话世界','339.00','18.jpg');
INSERT INTO `cake_alf_product` VALUES ('19','3', '彩虹天使','199.00','19.jpg');
INSERT INTO `cake_alf_product` VALUES ('20','3', '萌猫乐园','199.00','20.jpg');
INSERT INTO `cake_alf_product` VALUES ('21','3', '快乐时光','199.00','21.jpg');
INSERT INTO `cake_alf_product` VALUES ('22','3', '甜蜜花园','188.00','21.jpg');
INSERT INTO `cake_alf_product` VALUES ('23','3', '爱的告白','299.00','22.jpg');
INSERT INTO `cake_alf_product` VALUES ('24','3', '欢乐起航','299.00','23.jpg');
INSERT INTO `cake_alf_product` VALUES ('25','3', '小小旅行家','299.00','24.jpg');
INSERT INTO `cake_alf_product` VALUES ('26','3', '欢乐童年','239.00','25.jpg');
INSERT INTO `cake_alf_product` VALUES ('27','4', '一见倾心','299.00','26.jpg');
INSERT INTO `cake_alf_product` VALUES ('28','4', '甜蜜花舞','1499.00','27.jpg');
INSERT INTO `cake_alf_product` VALUES ('29','4', '欢聚','289.00','28.jpg');
INSERT INTO `cake_alf_product` VALUES ('30','4', '家美人和','188.00','29.jpg');
INSERT INTO `cake_alf_product` VALUES ('31','4', '提拉米苏','399.00','30.jpg');
INSERT INTO `cake_alf_product` VALUES ('32','4', '花样男神','229.00','31.jpg');
INSERT INTO `cake_alf_product` VALUES ('33','4', '美丽人生','188.00','32.jpg');
INSERT INTO `cake_alf_product` VALUES ('34','4', '黑森林','229.00','33.jpg');
INSERT INTO `cake_alf_product` VALUES ('35','4', '心意满满','208.00','34.jpg');
INSERT INTO `cake_alf_product` VALUES ('36','4', '蜜桃轻舞','188.00','35.jpg');
INSERT INTO `cake_alf_product` VALUES ('37','4', '花漾甜心','209.00','36.jpg');
INSERT INTO `cake_alf_product` VALUES ('38','4', '鲜果物语','199.00','37.jpg');
INSERT INTO `cake_alf_product` VALUES ('39','4', '白雪之恋','199.00','38.jpg');
INSERT INTO `cake_alf_product` VALUES ('40','4', '华美盛宴','499.00','39.jpg');
INSERT INTO `cake_alf_product` VALUES ('41','4', '幸福男神','299.00','40.jpg');
INSERT INTO `cake_alf_product` VALUES ('42','5', '大爱无疆','499.00','41.jpg');
INSERT INTO `cake_alf_product` VALUES ('43','5', '福寿盈门','399.00','42.jpg');
INSERT INTO `cake_alf_product` VALUES ('44','5', '福寿康宁','369.00','43.jpg');
INSERT INTO `cake_alf_product` VALUES ('45','5', '春辉永绽','399.00','44.jpg');
INSERT INTO `cake_alf_product` VALUES ('46','5', '华贵天香','599.00','45.jpg');
INSERT INTO `cake_alf_product` VALUES ('47','5', '仙桃献瑞','469.00','46.jpg');
INSERT INTO `cake_alf_product` VALUES ('48','5', '天伦永享','269.00','47.jpg');
INSERT INTO `cake_alf_product` VALUES ('49','5', '蟠桃捧日','499.00','48.jpg');
INSERT INTO `cake_alf_product` VALUES ('50','5', '华美盛宴','499.00','49.jpg');
INSERT INTO `cake_alf_product` VALUES ('51','5', '幸福男神','299.00','50.jpg');
INSERT INTO `cake_alf_product` VALUES ('52','6', '好利来x哈根达斯联名','138.00','51.jpg');
INSERT INTO `cake_alf_product` VALUES ('53','6', '半熟花花马卡龙-七夕情人节礼盒','62.00','52.jpg');
INSERT INTO `cake_alf_product` VALUES ('54','6', '好利来×小马宝莉联名云朵芝士','42.00','53.jpg');
INSERT INTO `cake_alf_product` VALUES ('55','6', '爆浆球','32.00','54.jpg');
INSERT INTO `cake_alf_product` VALUES ('56','6', '雪顶戚风','22.00','55.jpg');
INSERT INTO `cake_alf_product` VALUES ('57','6', '层层爆浆葡萄蛋糕','79.00','56.jpg');
INSERT INTO `cake_alf_product` VALUES ('58','6', '雪绒芝士','49.00','57.jpg');
INSERT INTO `cake_alf_product` VALUES ('59','6', '海盐玫瑰小酥','29.00','58.jpg');
INSERT INTO `cake_alf_product` VALUES ('60','6', '生巧克力','69.00','59.jpg');
INSERT INTO `cake_alf_product` VALUES ('61','6', '生吐司','28.00','60.jpg');
INSERT INTO `cake_alf_product` VALUES ('62','6', '冰山熔岩','59.00','61.jpg');
INSERT INTO `cake_alf_product` VALUES ('63','6', '蒲公英空气巧克力','59.00','62.jpg');
INSERT INTO `cake_alf_product` VALUES ('64','6', '北海道芝士牧场','45.00','63.jpg');
INSERT INTO `cake_alf_product` VALUES ('65','6', '半熟芝士','39.00','64.jpg');
INSERT INTO `cake_alf_product` VALUES ('66','6', '玫瑰绿豆糕','39.00','65.jpg');

-- ----------------------------
-- Table structure for `cake_alf_details`
-- ----------------------------
DROP TABLE IF EXISTS `cake_alf_details`;
CREATE TABLE `cake_alf_details` (
  `pid` int(11) NOT NULL auto_increment,
  `family_id` int(11) default NULL,
  `carousel_pics1` varchar(128) default NULL,
  `carousel_pics2` varchar(128) default NULL,
  `title` varchar(128) default NULL,
  `price` decimal(10,2) default NULL,
  `cake_size1` varchar(100) default NUll,
  `cake_size2` varchar(100) default NUll,
  `list_pics1` varchar(128) default NULL,
  `list_pics2` varchar(128) default NULL,
  `list_pics3` varchar(128) default NULL,
  PRIMARY KEY  (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cake_alf_details
-- ----------------------------
INSERT INTO `cake_alf_details` VALUES (
	'1', 
	'1',
	'banner1-1.jpg',
	'banner1-2.jpg',
	'奥利奥蛋糕',
	'279.00',
	'奥利奥派对层层-15cm*5.5cm-奥利奥芝士巧克力口味',
	'',	
	'1-1.jpg',
	'1-2.jpg',
	'1-3.jpg'
	);
INSERT INTO `cake_alf_details` VALUES (
	'2', 
	'1',
	'banner2-1.jpg',
	'banner2-2.jpg',
	'小马宝莉联名款生日蛋糕',
	'279.00',
	'云朵宝莉-15*5.5cm-玫瑰树莓芒果芝士口味',
	'魔法宝莉-15*7cm-玫瑰树莓芒果芝士口味',	
	'2-1.jpg',
	'2-2.jpg',
	'2-3.jpg'
	);
INSERT INTO `cake_alf_details` VALUES (
	'3', 
	'1',
	'banner3-1.jpg',
	'banner3-2.jpg',
	'RIO联名款生日蛋糕',
	'269.00',
	'微醺派对-15*7cm 心动桃桃-14*6cm',
	'',	
	'3-1.jpg',
	'3-2.jpg',
	'3-3.jpg'
	);
INSERT INTO `cake_alf_details` VALUES (
	'4', 
	'1',
	'banner4-1.jpg',
	'banner4-2.jpg',
	'小马宝莉联名蛋糕',
	'269.00',
	'甜梦宝莉-14cm*9cm-玫瑰树莓芒果芝士口味',
	'',	
	'4-1.jpg',
	'4-2.jpg',
	'4-3.jpg'
	);
INSERT INTO `cake_alf_details` VALUES (
	'5', 
	'1',
	'banner5-1.jpg',
	'banner5-2.jpg',
	'多肉葡萄蛋糕',
	'279.00',
	'葡萄茉莉味-萄气波波：（12cm*12.5cm）',
	'',	
	'5-1.jpg',
	'5-2.jpg',
	'5-3.jpg'
	);
INSERT INTO `cake_alf_details` VALUES (
	'6', 
	'1',
	'banner6-1.jpg',
	'banner6-2.jpg',
	'多肉葡萄蛋糕-萄气乐园',
	'279.00',
	'萄气乐园：（14cm*8cm）-葡萄茉莉味',
	'',	
	'6-1.jpg',
	'6-2.jpg',
	'6-3.jpg'
	);
