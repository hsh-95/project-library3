import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
//导入页面组件
import Product from '../views/product'
import Details from '../views/details'


// 项目实践页面
import Register from '../views/Register.vue';
import Login from '../views/Login.vue';
import Cart from '../views/cart.vue'

Vue.use(VueRouter)

const routes = [
  {
    path:'/cart',
    component:Cart
  },
  {
    path:'/details/:pid',
    component:Details
  },
  {
    path:'/product/:family_id',
    component:Product
  },
  {
    path:'/register',
    component:Register
  },
  {
    path:'/login',
    component:Login
  },
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/about',
    name: 'About',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
