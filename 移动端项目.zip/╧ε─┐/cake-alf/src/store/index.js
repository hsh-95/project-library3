import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'
import qs from 'qs'
import router from '../router'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    //标识用户是否已经登录
    isLogined:localStorage.getItem('isLogined') ? localStorage.getItem('isLogined') : 0,
    phone:localStorage.getItem('phone') ? localStorage.getItem('phone') : ''
  },
  mutations: {
    logined(state,payload){
      state.isLogined = 1;
      state.phone = payload.phone;
      localStorage.setItem('phone',payload.phone)
    },
    logout(state){
      state.isLogined = 0;
      state.phone = '';
      localStorage.removeItem('isLogined')
    }
  },
  actions: {
    login(context,payload){
       console.log(payload);
       axios.post('/login',qs.stringify(payload)).then(res=>{
          console.log(res.data);
          if(res.data.code == 1){
            context.commit('logined',res.data.info);
            localStorage.setItem('isLogined','1');
            router.push('/')
          }else{
            alert("用户名或密码错误");
          }
       })
    }
  },
  modules: {
  }
})
