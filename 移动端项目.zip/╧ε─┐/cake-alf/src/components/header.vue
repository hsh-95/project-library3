<template>
    <div>
        <div>
     <mt-header title="" class="header">
       <div slot="left" class="header_left">
         <router-link to="/">
             <img src="../assets/img/logo/logo.png" alt="">
         </router-link>
       </div>
       <div slot="right" class="header_right" v-if="this.$store.state.isLogined == 0">
         <router-link to="/login">登录</router-link>
         |
         <router-link to="/register">注册</router-link>
       </div>
       <div slot="right" class="shortcut" v-else>
         {{this.$store.state.username}}
       </div>
     </mt-header>
   </div>
    </div>
</template>
<style scope>
    *{
  margin: 0;
  padding: 0;
}
a{
  text-decoration: none;
}
.header{
  z-index: 999;
  background-color: #f9f9f9 !important;
  position: relative;
  height: 60px !important;
  border-bottom: 1px solid #dddddd;
}
.header_left{
    width: 160px;
    height: 60px;
}
.header_left img{
    width: 120px;
    padding-top: 10px;
}
.header_right{
  padding-top: 20px;
  color: skyblue;
}
.header_right a{
  color: skyblue;
  margin: 0 5px 0 5px;
}
</style>