<template>
    <div>
      <div style="width:100%;height:282px">
        <mt-swipe :auto="4000">
          <mt-swipe-item>
            <img :src="imags.carousel_pics1" alt=""/>
          </mt-swipe-item>
          <mt-swipe-item>
            <img :src="imags.carousel_pics2" alt=""/>
          </mt-swipe-item>
        </mt-swipe>
      </div>
        <div class="g_g">
            <ul class="bg_fff list_text">
                <li class="border_b p10">
                     {{imags.title}}
                     <p class="c_blue">￥{{imags.price}}.00</p>
                </li>
                <li class="p10">
                    <em class="c_999">规格：</em>
                    {{imags.cake_size1}}
                    {{imags.cake_size2}}
                </li>
            </ul>
        </div>  
        <div class="m_s">
            <p>
                <img :src="imags.list_pics1" alt="">
                <img :src="imags.list_pics2" alt="">
                <img :src="imags.list_pics3" alt="">
            </p>    
        </div>  
    <div class="s-x block" id="cart" style="display:none">
      <div class="name-card">
        <div class="thumb">
          <img :src="imags.carousel_pics1" alt=""/>
        </div>
        <div class="ui-list-info">
          <h4 class="ui-nowrap">{{imags.title}}</h4>
          <p class="ui-nowrap c-blue shop-price">￥{{imags.price}}.00</p>
        </div>
        <div class="close-img" @click="closeCart"></div>
      </div>
      <div class="su-x">
        <ul>
          <li id="ys" class="ui-border-b" style="height:300px;overflow:auto">
            <h3>规格：</h3>
            <i class="yh radius attrs">
              {{imags.cake_size1}}
            </i>
            <i class="yh radius attrs">
              {{imags.cake_size2}}
            </i>
          </li>
          <li class="ui-border-b">
            <h3 class="f">数量：</h3>
            <div class="xz r radius5" style="border-radius:3px">
              <span style="cursor:pointer;border-right:1px solid #ccc;padding-top:5px;">-</span>
              <input type="text" class="slnum" value="1">
              <span style="cursor:pointer;border-left:1px solid #ccc;padding-top:5px">+</span>
            </div>
          </li>
          <li class="ui-border-b" style="border-bottom:0;padding:0;">
            <div style="border-bottom:1px solid #ccc;overflow:hidden;padding:10px 0">
              免费餐具：
              <div style="width:87px;border:1px solid #dddddd;border-radius:3px;overflow:hidden;height:24px;float:right;">
                <select style="width:107px;height:24px;padding-left:20%;" class="select_canju">
                  <option value="2人份">2人份▼</option>
                  <option value="不要餐具">不要餐具</option>
                  <option value="3人份">3人份</option>
                  <option value="4人份">4人份</option>
                  <option value="5人份">5人份</option>
                  <option value="6人份">6人份</option>
                  <option value="7人份">7人份</option>
                  <option value="8人份">8人份</option>
                  <option value="9人份">9人份</option>
                  <option value="10人份">10人份</option>
                  <option value="11人份">11人份</option>
                  <option value="12人份">12人份</option>
                </select>
              </div>
            </div>
          </li>
          <li>
            <router-link to="/cart">
              <mt-button type="primary" size="large" style="background:yellow;color:gray">下一步</mt-button>
            </router-link>
          </li>
        </ul>
      </div>
    </div>
    <div class="cart_list">
      <mt-button type="default" size="normal" style="width:49%;height:30px;font-size: 14px;" @click="closeCart">加入购物车</mt-button>
      <mt-button type="primary" size="normal" style="background:yellow;width:49%;height:30px;color:gray;font-size: 14px;">立即购买</mt-button>
    </div>    
    <div class="footer">
      <ul class="row_flex">
        <li class="footer_col txt_c">
          <router-link to="/">主页</router-link>
        </li>
        <li class="footer_col txt_c" @click="listShow" >
            <i></i>
            产品
          <div class="pfk kjia" id="cakeSort">
            <ul>
              <router-link to="/product/1">
                <li>新品系列</li>
              </router-link>
              <router-link to="/product/2">
                <li>经典系列</li>
              </router-link>
              <router-link to="/product/3">
                <li>儿童系列</li>
              </router-link>
              <router-link to="/product/4">
                <li>珍爱系列</li>
              </router-link>
              <router-link to="/product/5">
                <li>尊爱系列</li>
              </router-link>
              <router-link to="/product/6">
                <li>和风系列</li>
              </router-link>
            </ul>
            <em></em>
          </div>
        </li>
        <li class="footer_col txt_c">
          <router-link to="/product/6">和风软点</router-link>
        </li>
        <li class="footer_col txt_c" @click="helpCenterShow">
            <i></i>
            帮助中心
          <div class="pfk kjia" style="left:276px" id="helpCenter" >
            <ul>
              <router-link to="javascript:;">
                <li>会员中心</li>
              </router-link>
              <router-link to="javascript:;">
                <li>门店列表</li>
              </router-link>
              <router-link to="javascript:;">
                <li>储值卡查询</li>
              </router-link>
            </ul>
            <em></em>
          </div>
        </li>
      </ul>
   </div>

    </div>    
</template>
<style scoped>
.swiper{
  width: 100%;
  /* height: 281px; */
}
.swiper img{
  width: 100%;
  height: 281px;
  max-width: 500px;
}
.bg_fff{
    background:#fff;
}
.list_text>li{
    position: relative;
    padding-top: 10px;
    padding-bottom: 10px;
    padding-right: 15px;
    -webkit-box-align: center;
}
.border_b{
    border-bottom: 1px solid #f1f1f1;
}
.p10{
    padding: 0 10px;
}
.c_blue{
  margin-top: 10px;
    color: #2093cc;
}
.c_999{
    color: #999;
}
.m_s{
    padding: 10px;
    line-height: 24px;
}
img{
    width: 100%;
    display: block;
}
.cart_list{
  position: fixed;
  width: 375px;
  bottom: 45px;
  text-align: center;
  z-index: 100;
  display: flex;
  justify-content: space-around;
  padding: 10px 0 10px 0;
  background: white;
}
.footer{
  bottom: 0;
    height: 45px;
    position: fixed;
    width: 100%;
    z-index: 100;
    left: 0;
    background: #fafafa;
    border-top: 1px solid #dfdfdf;
}
.footer ul{
  height: 100%;
}
.row_flex{
   display: -webkit-box;
    width: 100%;
    -webkit-box-align: center;
}
.footer ul li{
   border-right: 1px solid #d0d0d0;
   height: 100%;
   line-height: 45px;
}
.txt_c{
  text-align: center !important;
}
.footer_col{
   padding: 1px;
   float: none;
   -webkit-box-flex: 1;
   width: 0;
}
.footer_col a{
  color: #626262;
}
.footer ul li i{
    display: inline-block;
    width: 12px;
    height: 12px;
    background: #bfbfbf;
    vertical-align: middle;
    margin-right: 10px;
    -webkit-border-radius: 20px;
    border-radius: 20px;
}
.footer ul li i:after{
    content: '';
    width: 50%;
    margin: 0 auto;
    height: 4px;
    border-bottom: 1px solid #fff;
    border-top: 1px solid #fff;
    display: block;
    margin-top: 4px;
}
.pfk{
    position: absolute;
    bottom: 55px; 
    left: 85px;
    background: #fff;
    width: 26%;
    /* border: 1px solid #ccc; */
    border-radius: 5px;
    display: none;
}
.pfk ul{
  height: auto;
}
.pfk li{
    padding: 0;
    margin: 0;
    height: 30px;
    line-height: 30px;
    border: 0;
    border-right: none !important;
    border-bottom: 1px solid #ccc;
    margin: 0 10px;
    position: relative;
    bottom: -1px;
}
.pfk em{
    display: block;
    border-width: 10px;
    position: absolute;
    bottom: -20px;
    border-style: solid dashed dashed;
    border-color: #fff transparent transparent;
    font-size: 0;
    line-height: 0;
    left: 50%;
    margin-left: -10px;
}
.s-x.block{
  bottom: 45px;
}
.s-x{
    left: 0px;
    right: 0px;
    overflow: hidden;
    position: fixed;
    z-index: 500;
    transform: translate3d(0px, 0px, 0px);
    transition: all 300ms ease;
    opacity: 1;
    background: white;
}
.name-card{
  position: relative;
  display: flex;
  border-bottom: 1px solid lightgray;
}
.thumb{
  width: 40px;
  height: 40px;
  margin: 10px;
}
.ui-list-info{
  padding-top: 10px;
  padding-bottom: 10px;
  box-sizing: border-box;
  padding-right: 15px;
}
.ui-nowrap{
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.close-img {
    cursor: pointer;
    width: 40px;
    height: 40px;
    position: absolute;
    right: 10px;
    top: 50%;
    margin-top: -20px;
    background: url(../assets/img/logo/ico-close.png) no-repeat center;
    background-size: 27px;
}
.su-x{
  overflow-y: scroll;
  padding: 0 10px;
}
.su-x li{
  padding: 10px 0;
  border-bottom: 1px solid lightgray;
  overflow: hidden;
}
.su-x h3{
  font-weight: normal;
  padding-bottom: 5px;
}
.su-x li i.select {
    border: 1px solid #ed2501;
}
h3{
  font-size: 14px;
}
.su-x li i {
    cursor: pointer;
    display: inline-block;
    vertical-align: middle;
    border: 1px solid #dddddd;
    margin-right: 5px;
    padding: 5px 5px;
    margin-bottom: 5px;
    font-style: normal;
    font-size: 14px;
}
.f{
  float: left;
  margin-top: 11px;
}
.su-x li .xz {
    border: 1px solid #ccc;
    float: right;
    background-color: #fff;
}
.su-x li .xz span {
    float: left;
    display: block;
    font-size: 16px;
    font-weight: bold;
    text-align: center;
    width: 25px;
    height: 24px;
}
.su-x li .xz .slnum {
    height: 29px;
    width: 35px;
    display: block;
    float: left;
    text-align: center;
    line-height: 24px;
    border: none;
}
</style>
<script>
export default {
  data(){
    return {
      imags:[],
      info:[],
      sortShow: false,
      helpShow: false,
      close:false
    }
  },
  mounted(){
    let id = this.$route.params.pid
    this.axios.get('/details?pid=' +id).then(res=>{
        // console.log(res.data);
        // this.info = res.data;
      let data = res.data;
      
      data.forEach(item=>{
          item.carousel_pics1 = require('../assets/img/details/'+item.carousel_pics1);
          item.carousel_pics2 = require('../assets/img/details/'+item.carousel_pics2);
          item.list_pics1 = require('../assets/img/details/'+item.list_pics1);
          item.list_pics2 = require('../assets/img/details/'+item.list_pics2);
          item.list_pics3 = require('../assets/img/details/'+item.list_pics3);
          this.info.push(item)
          console.log(this.info);
        });
        //解决遍历出来的数据为undefined的情况
        this.imags = this.info[0]
    })   
   },
   methods:{
    listShow(){
      let cakeSort = document.getElementById('cakeSort');
      let helpCenter = document.getElementById('helpCenter');
      if(!this.sortShow){
         cakeSort.style.display = "block";
         helpCenter.style.display = "none";
        this.helpShow = false;
         this.sortShow = true
      }else if(this.sortShow){
        cakeSort.style.display = "none";
        this.sortShow = false;
      }
    },
    helpCenterShow(){
      let cakeSort = document.getElementById('cakeSort');
      let helpCenter = document.getElementById('helpCenter');
      if(!this.helpShow){
         helpCenter.style.display = "block";
         cakeSort.style.display = "none";
         this.sortShow = false;
         this.helpShow = true
      }else if(this.helpShow){
        helpCenter.style.display = "none";
        this.helpShow = false;
      }
    },
    closeCart(){
      let cart = document.getElementById('cart');
      if(this.close){
        cart.style.display = "none";
        this.close = false
      }else{
        cart.style.display = "block";
        this.close = true
      }
    }
   }   
}

</script>
