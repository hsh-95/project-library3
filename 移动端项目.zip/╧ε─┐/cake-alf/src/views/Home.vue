<template>
  <div>
   <!-- 顶部导航 -->
   <div>
     <mt-header title="" class="header">
       <div slot="left" class="header_left">
         <router-link to="/">
             <img src="../assets/img/logo/logo.png" alt="">
         </router-link>
       </div>
       <div slot="right" class="header_right" v-if="this.$store.state.isLogined == 0">
         <router-link to="/login">登录</router-link>
         |
         <router-link to="/register">注册</router-link>
         |
         <router-link to="/login">购物车</router-link>
       </div>
       <div slot="right" class="shortcut" v-else style="color:red">
         {{this.$store.state.phone}}
         |
         <mt-button type="primary" @click="logout" style="color:red">注销</mt-button>
       </div>
     </mt-header>
   </div>
   <!-- 轮播图  -->
   <div class="carousel">
      <div class="banner">
        <swiper class="swiper" :options="swiperOption" >
          <swiper-slide v-for="(v,i) of imags" :key="i">
            <img :src="v.img" alt=""/>
        </swiper-slide>
        <div class="swiper-pagination" slot="pagination"></div>
        <!-- <div class="swiper-button-prev" slot="button-prev"></div>
        <div class="swiper-button-next" slot="button-next"></div> -->
        </swiper>
      </div>
   </div>
   <!-- 搜索框 -->
   <div class="serch">
     <button type="submit" class="btn" @click="search(searchKey)"></button>
     <input type="search" name="keywords" placeholder="商品搜索：请输入关键字" class="input radius5" v-model="searchKey">
   </div>
   <div class="nav">
     <ul class="nav-list">
       <li>
         <router-link to="/product/1">
          <img src="../assets/img/product/1.jpg" alt="">
         </router-link>
       </li>
       <li>
         <router-link to="/product/2">
          <img src="../assets/img/product/2.jpg" alt="">
         </router-link>
       </li>
     </ul>
     <ul class="row_flex">
       <li class="f_col">
         <router-link to="/product">
           <img src="../assets/img/product/3.jpg" alt="">
         </router-link>
       </li>
       <li class="f_col">
         <router-link to="/product">
           <img src="../assets/img/product/4.jpg" alt="">
         </router-link>
       </li>
       <li class="f_col">
         <router-link to="/product">
           <img src="../assets/img/product/5.jpg" alt="">
         </router-link>
       </li>
     </ul>
   </div>
   <div class="footer">
      <ul class="row_flex">
        <li class="footer_col txt_c">
          <router-link to="/">主页</router-link>
        </li>
        <li class="footer_col txt_c" @click="listShow" >
            <i></i>
            产品
          <div class="pfk kjia" id="cakeSort">
            <ul>
              <router-link to="/product/1">
                <li>新品系列</li>
              </router-link>
              <router-link to="/product/2">
                <li>经典系列</li>
              </router-link>
              <router-link to="/product/3">
                <li>儿童系列</li>
              </router-link>
              <router-link to="/product/4">
                <li>珍爱系列</li>
              </router-link>
              <router-link to="/product/5">
                <li>尊爱系列</li>
              </router-link>
              <router-link to="/product/6">
                <li>和风系列</li>
              </router-link>
            </ul>
            <em></em>
          </div>
        </li>
        <li class="footer_col txt_c">
          <router-link to="/product/6">和风软点</router-link>
        </li>
        <li class="footer_col txt_c" @click="helpCenterShow">
            <i></i>
            帮助中心
          <div class="pfk kjia" style="left:276px" id="helpCenter" >
            <ul>
              <router-link to="javascript:;">
                <li>会员中心</li>
              </router-link>
              <router-link to="javascript:;">
                <li>门店列表</li>
              </router-link>
              <router-link to="javascript:;">
                <li>储值卡查询</li>
              </router-link>
            </ul>
            <em></em>
          </div>
        </li>
      </ul>
   </div>
  </div> 
</template>
<style scoped>
ul{
  list-style: none;
}
*{
  margin: 0;
  padding: 0;
}
a{
  text-decoration: none;
}
.header{
  z-index: 999;
  background-color: #f9f9f9;
  position: relative;
  height: 60px;
  border-bottom: 1px solid #dddddd;
}
.header_left{
    width: 160px;
    height: 60px;
}
.header_left img{
    width: 120px;
    padding-top: 10px;
}
.header_right{
  padding-top: 20px;
  color: skyblue;
}
.header_right a{
  color: skyblue;
  margin: 0 5px 0 5px;
}
.swiper{
  width: 100%;
  height: 168px;
}
.swiper img{
  width: 100%;
  height: 100%;
  max-width: 500px;
}
.serch{
  position: relative;
  padding: 10px;
}
.serch .btn{
    display: block;
    position: absolute;
    left:20px;
    top: 14px;
    border: none;
    width: 29px;
    height: 29px;
    background: url(../assets/img/logo/ico-reach.png) no-repeat center left;
    background-size: 20px;
}
.input{
  padding-left: 30px;
}
.serch input{
    width: 100%;
    font-size: 16px;
    line-height: 1rem;
    color: #555;
    height: 38px;
    background: white;
    box-sizing: border-box;
    background-color: #fff;
    border: 1px solid #ccc;
    border-radius: 5px;
    padding-left: 40px;
}
a:visited{
  font-size: 14px;
  text-decoration: none;
}
.nav-list li img {
    display: block;
    width: 100%;
}
.row_flex{
  display: -webkit-box;
  /* justify-content: space-around; */
}
.f_col{
  padding: 1px;
  -webkit-box-flex:1;
  /* width: 0; */
}
.f_col img{
  width: 100%;
  display: block;
}
.footer{
  bottom: 0;
    height: 45px;
    position: fixed;
    width: 100%;
    z-index: 100;
    left: 0;
    background: #fafafa;
    border-top: 1px solid #dfdfdf;
}
.footer ul{
  height: 100%;
}
.row_flex{
   display: -webkit-box;
    width: 100%;
    -webkit-box-align: center;
}
.footer ul li{
   border-right: 1px solid #d0d0d0;
   height: 100%;
   line-height: 45px;
}
.txt_c{
  text-align: center !important;
}
.footer_col{
   padding: 1px;
   float: none;
   -webkit-box-flex: 1;
   width: 0;
}
.footer_col a{
  color: #626262;
}
.footer ul li i{
    display: inline-block;
    width: 12px;
    height: 12px;
    background: #bfbfbf;
    vertical-align: middle;
    margin-right: 10px;
    -webkit-border-radius: 20px;
    border-radius: 20px;
}
.footer ul li i:after{
    content: '';
    width: 50%;
    margin: 0 auto;
    height: 4px;
    border-bottom: 1px solid #fff;
    border-top: 1px solid #fff;
    display: block;
    margin-top: 4px;
}
.pfk{
    position: absolute;
    bottom: 55px; 
    left: 85px;
    background: #fff;
    width: 26%;
    /* border: 1px solid #ccc; */
    border-radius: 5px;
    display: none;
}
.pfk ul{
  height: auto;
}
.pfk li{
    padding: 0;
    margin: 0;
    height: 30px;
    line-height: 30px;
    border: 0;
    border-right: none !important;
    border-bottom: 1px solid #ccc;
    margin: 0 10px;
    position: relative;
    bottom: -1px;
}
.pfk em{
    display: block;
    border-width: 10px;
    position: absolute;
    bottom: -20px;
    border-style: solid dashed dashed;
    border-color: #fff transparent transparent;
    font-size: 0;
    line-height: 0;
    left: 50%;
    margin-left: -10px;
}
</style>
<script>
import { Swiper, SwiperSlide } from "vue-awesome-swiper";
import "swiper/css/swiper.css";
export default {
  name: "swiper-example-autoplay",
  title: "Autoplay",
  components: {
    Swiper,
    SwiperSlide,
  },
  data(){
    return {
      swiperOption: {
        spaceBetween: 30,
        centeredSlides: true,
        autoplay: {
          delay: 1000,
          disableOnInteraction: false,
        },
        loop: true,
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        effect: "fade",
        fadeEffect: {
          crossFade: true,
        },
        speed: 3000,
        // navigation: {
        //   nextEl: ".swiper-button-next",
        //   prevEl: ".swiper-button-prev",
        // },
      },
      imags:[],
      searchKey:'',
      sortShow: false,
      helpShow: false
    }
  },
  methods:{
    logout(){
      this.$store.commit('logout')
    },
    loadDate(){
    this.$indicator.open({ 
        text:'加载中...',
        spinnerType:'double-bounce'
      });
    },
    search(searchKey){
       this.$router.push(
         {path:`/product/${searchKey}`}
       );
      console.log(searchKey)
    },
    listShow(){
      let cakeSort = document.getElementById('cakeSort');
      let helpCenter = document.getElementById('helpCenter');
      if(!this.sortShow){
         cakeSort.style.display = "block";
         helpCenter.style.display = "none";
        this.helpShow = false;
         this.sortShow = true
      }else if(this.sortShow){
        cakeSort.style.display = "none";
        this.sortShow = false;
      }
    },
    helpCenterShow(){
      let cakeSort = document.getElementById('cakeSort');
      let helpCenter = document.getElementById('helpCenter');
      if(!this.helpShow){
         helpCenter.style.display = "block";
         cakeSort.style.display = "none";
         this.sortShow = false;
         this.helpShow = true
      }else if(this.helpShow){
        helpCenter.style.display = "none";
        this.helpShow = false;
      }
    }
  },
  created(){
    window.addEventListener("resize",()=>{
      this.innerWidth=window.innerWidth;
    })
    // this.start();
  },
  mounted(){
    this.axios.get('/carousel').then(results=>{
      let data = results.data.results;
      data.forEach(item=>{
          item.img = require('../assets/img/carousel/'+item.img)
          this.imags.push(item);
        });
  });
  }
}
</script>