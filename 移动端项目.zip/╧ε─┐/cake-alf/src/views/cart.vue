<template>
    <div>
        <div class="block">
            <section class="gw-c">
                <div>
                    <ul class="ui-list ui-list-one cp">
                        <li class="ui-border-b" style="display:flex">
                            <label class="ui-checkbox-s">
                                <input type="checkbox" checked>
                            </label>
                            <div class="ui-list-thumb">
                                <img src="../assets/img/details/banner1-1.jpg" alt=""> 
                            </div>
                            <div class="ui-list-info">
                                <div class="ms" style="float:left;margin-top:14px">
                                    <h4 class="ui-nowrap" style="overflow:hidden">好利来X小马宝莉联名款生日蛋糕</h4>
                                    <p class="c-ccc">云朵宝莉-15*5.5cm-玫瑰树莓芒果芝士口味</p>
                                </div> 
                                <div class="ui-txt-info"  style="float:left;margin-top:22px">
                                    <p>￥279.00</p>
                                    <p>x1</p>
                                    <div> 
                                        <span class="date c-ccc del_goods" style="cursor:pointer;">删除</span>
                                        <div class="s-l">
                                            <span class="min change" style="cursor:pointer;border-right:1px solid #ccc">-</span>
                                            <input type="text" class="slnum" value='1'>
                                            <span class="add change" style="cursor:pointer;border-left:1px solid #ccc">+</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul> 
                </div>
                <div class="kx ui-border-b look_fujia">
                   <span class="k-x" style="width:100%;text-align:center;">
                    可选专属附加产品  
                   </span>  
                </div>
                <div class="x-d">
                     <span class="tx-l">
                         <p class="all" style="cursor:pointer">全选</p>
                         <p class="date del_all" style="cursor:pointer;padding-right:0;color:lightblack">删除</p>
                     </span>
                     <span class="tx-r">
                         <p class="c-cc" style="color:#626262">（不含运费）</p>
                         <p class="price c-blue">总计:￥279.00</p>
                         <mt-button type="primary" size="normal"  class="x-b" style="background:yellow;height:30px;margin-right:22px;color:gray;fontSize:15px">下一步</mt-button>
                     </span>
                </div>
            </section>
        </div> 

    <div class="footer">
      <ul class="row_flex">
        <li class="footer_col txt_c">
          <router-link to="/">主页</router-link>
        </li>
        <li class="footer_col txt_c" @click="listShow" >
            <i></i>
            产品
          <div class="pfk kjia" id="cakeSort">
            <ul>
              <router-link to="/product/1">
                <li>新品系列</li>
              </router-link>
              <router-link to="/product/2">
                <li>经典系列</li>
              </router-link>
              <router-link to="/product/3">
                <li>儿童系列</li>
              </router-link>
              <router-link to="/product/4">
                <li>珍爱系列</li>
              </router-link>
              <router-link to="/product/5">
                <li>尊爱系列</li>
              </router-link>
              <router-link to="/product/6">
                <li>和风系列</li>
              </router-link>
            </ul>
            <em></em>
          </div>
        </li>
        <li class="footer_col txt_c">
          <router-link to="/product/6">和风软点</router-link>
        </li>
        <li class="footer_col txt_c" @click="helpCenterShow">
            <i></i>
            帮助中心
          <div class="pfk kjia" style="left:276px" id="helpCenter" >
            <ul>
              <router-link to="javascript:;">
                <li>会员中心</li>
              </router-link>
              <router-link to="javascript:;">
                <li>门店列表</li>
              </router-link>
              <router-link to="javascript:;">
                <li>储值卡查询</li>
              </router-link>
            </ul>
            <em></em>
          </div>
        </li>
      </ul>
   </div>
    </div>
</template>
<style scoped>
.gw-c {
    border-bottom: 101px solid transparent;
}
.ui-list {
    background-color: #fff;
    width: 100%;
}
.gw-c ul.cp li {
    padding-left: 30px;
    position: relative;
}
.gw-c ul.cp li {
    padding-left: 30px;
    position: relative;
}
.ui-border-b {
    border-bottom: 1px solid #f1f1f1;
}
label {
    display: inline-block;
    margin-bottom: 5px;
    font-weight: 400;
}
.ui-checkbox, .ui-checkbox-s, .ui-radio {
    display: inline-block;
    position: relative;
    overflow: hidden;
}
.gw-c ul.cp li .ui-checkbox-s {
    position: absolute;
    left: 10px;
    top: 50%;
    margin-top: -11px;
}
.ui-checkbox input, .ui-radio input, .ui-checkbox-s input {
    display: inline-block;
    width: 18px;
    height: 18px;
    position: relative;
    overflow: visible;
    background: #fff;
    border: 1px solid #d2d2d2;
    -webkit-appearance: none;
    outline: 0;
    margin-right: 8px;
    vertical-align: middle;
    -webkit-border-radius: 100px;
}
.ui-list-thumb {
    width: 80px;
    height: 80px;
    margin: 10px;
    position: relative;
}
img {
    width: 100%;
    display: block;
}
.ui-list-info {
    -webkit-box-align: start;
}
.ms {
    -webkit-box-flex: 1;
    -webkit-box-align: start;
    width: 107px;
}
.ui-nowrap {
    max-width: 100%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}
h4 {
    font-size: 14px;
    font-weight: 400;
}
.c-ccc {
    color: #ccc;
}
.ui-txt-info {
    text-align: right;
}
.s-l {
    border: 1px solid #d2d2d2;
    display: inline-block;
    vertical-align: middle;
    margin-left: 10px;
}
.s-l span {
    display: inline-block;
    background: #fff;
    float: left;
    font-size: 16px;
    font-weight: bold;
    text-align: center;
    line-height: 25px;
    width: 25px;
}
.date{
    color:red;
}
.slnum {
    border: none;
    height: 25px;
    width: 40px;
    display: block;
    float: left;
    text-align: center;
    line-height: 24px;
}
.kx {
    padding: 10px;
}
.k-x {
    background: #ededed;
    padding: 5px 10px;
    display: inline-block;
}
.gw-c .kx .k-x:after {
    content: " ";
    display: inline-block;
    vertical-align: middle;
    margin-left: 5px;
    width: 20px;
    height: 10px;
    background: url(../assets/img/logo/ico_jt.png) no-repeat 0 -10px;
    background-size: 15px;
}
.x-d {
    position: fixed;
    padding: 10px;
    background: #ededed;
    left: 0;
    width: 100%;
    bottom: 45px;
    overflow: hidden;
    display: flex;
    justify-content: space-between;
}
.tx-l {
    text-align: left;
    display: block;
    float: left;
    height: 31px;
    line-height: 31px;
    font-size: 13px;
    display: flex;
}
.x-d .tx-l a {
    padding-right: 10px;
    font-size: 13px;
}
.tx-r {
    text-align: right;
    display: block;
    float: right;
    height: 31px;
    font-size: 13px;
    display: flex;
}
.all{
    margin-right: 28px;
}
.c-cc{
    margin-right: 15px;
    margin-top: 8px;
}
.c-blue{
    margin-right: 15px;
    margin-top: 8px;
}
/* /////////// */
.footer{
  bottom: 0;
    height: 45px;
    position: fixed;
    width: 100%;
    z-index: 100;
    left: 0;
    background: #fafafa;
    border-top: 1px solid #dfdfdf;
}
.footer ul{
  height: 100%;
}
.row_flex{
   display: -webkit-box;
    width: 100%;
    -webkit-box-align: center;
}
.footer ul li{
   border-right: 1px solid #d0d0d0;
   height: 100%;
   line-height: 45px;
}
.txt_c{
  text-align: center !important;
}
.footer_col{
   padding: 1px;
   float: none;
   -webkit-box-flex: 1;
   width: 0;
}
.footer_col a{
  color: #626262;
}
.footer ul li i{
    display: inline-block;
    width: 12px;
    height: 12px;
    background: #bfbfbf;
    vertical-align: middle;
    margin-right: 10px;
    -webkit-border-radius: 20px;
    border-radius: 20px;
}
.footer ul li i:after{
    content: '';
    width: 50%;
    margin: 0 auto;
    height: 4px;
    border-bottom: 1px solid #fff;
    border-top: 1px solid #fff;
    display: block;
    margin-top: 4px;
}
.pfk{
    position: absolute;
    bottom: 55px; 
    left: 85px;
    background: #fff;
    width: 26%;
    /* border: 1px solid #ccc; */
    border-radius: 5px;
    display: none;
}
.pfk ul{
  height: auto;
}
.pfk li{
    padding: 0;
    margin: 0;
    height: 30px;
    line-height: 30px;
    border: 0;
    border-right: none !important;
    border-bottom: 1px solid #ccc;
    margin: 0 10px;
    position: relative;
    bottom: -1px;
}
.pfk em{
    display: block;
    border-width: 10px;
    position: absolute;
    bottom: -20px;
    border-style: solid dashed dashed;
    border-color: #fff transparent transparent;
    font-size: 0;
    line-height: 0;
    left: 50%;
    margin-left: -10px;
}
</style>
<script>
export default {
  data(){
    return {
      imags:[],
      info:[],
      sortShow: false,
      helpShow: false
    }
  },
  mounted(){
    let id = this.$route.params.pid
    this.axios.get('/details?pid=' +id).then(res=>{
        // console.log(res.data);
        // this.info = res.data;
      let data = res.data;
      
      data.forEach(item=>{
          item.carousel_pics1 = require('../assets/img/details/'+item.carousel_pics1);
          item.carousel_pics2 = require('../assets/img/details/'+item.carousel_pics2);
          item.list_pics1 = require('../assets/img/details/'+item.list_pics1);
          item.list_pics2 = require('../assets/img/details/'+item.list_pics2);
          item.list_pics3 = require('../assets/img/details/'+item.list_pics3);
          this.info.push(item)
          console.log(this.info);
        });
        //解决遍历出来的数据为undefined的情况
        this.imags = this.info[0]
    })   
   },
   methods:{
    listShow(){
      let cakeSort = document.getElementById('cakeSort');
      let helpCenter = document.getElementById('helpCenter');
      if(!this.sortShow){
         cakeSort.style.display = "block";
         helpCenter.style.display = "none";
        this.helpShow = false;
         this.sortShow = true
      }else if(this.sortShow){
        cakeSort.style.display = "none";
        this.sortShow = false;
      }
    },
    helpCenterShow(){
      let cakeSort = document.getElementById('cakeSort');
      let helpCenter = document.getElementById('helpCenter');
      if(!this.helpShow){
         helpCenter.style.display = "block";
         cakeSort.style.display = "none";
         this.sortShow = false;
         this.helpShow = true
      }else if(this.helpShow){
        helpCenter.style.display = "none";
        this.helpShow = false;
      }
    }
   }   
}

</script>