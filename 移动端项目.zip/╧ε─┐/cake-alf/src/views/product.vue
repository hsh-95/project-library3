<template>
    <div>
        <div class="lb_y">
            <ul class="ui_tiled bg_fff nav ui_border_b">
                <li class="on" @click="listShow1">
                    <em class="xl">经典系列</em>
                    <div class="x_l" id="cakeSort1">
                        <p @click="all">全部</p>
                        <p @click="jump(2)">金典系列</p>
                        <p @click="jump(3)">儿童系列</p>
                        <p @click="jump(4)">珍爱系列</p>
                    </div>
                </li>
                <li class="on" @click="priceShow">
                    <em>价格</em>
                    <div class="p_x" id="price">
                        <router-link to >价格</router-link>
                    </div>
                </li>
            </ul>
            <ul class="cp_list" >
                <li v-for="(v,i) of info" :key="i">
                    <div class="box">
                        <div class="imgur" >
                        <router-link :to="`/details/${v.pid}`">
                            <img :src="v.pic" alt="">
                        </router-link>
                    </div>
                    <div class="nowrap t">
                        <router-link to="">{{v.title}}</router-link>
                    </div>
                    <div class="j_g">
                        <em class="c_blue">{{v.price}}</em>
                        <router-link to="" class="tj"></router-link>
                    </div>
                    </div>
                </li>
            </ul>
            <div class="footer">
      <ul class="row_flex">
        <li class="footer_col txt_c">
          <router-link to="/">主页</router-link>
        </li>
        <li class="footer_col txt_c" @click="listShow" >
            <i></i>
            产品
          <div class="pfk kjia" id="cakeSort">
            <ul>
              <router-link to="/product/1">
                <li @click="jump(1)">新品系列</li>
              </router-link>
              <router-link to="/product/2">
                <li @click="jump(2)">经典系列</li>
              </router-link>
              <router-link to="/product/3">
                <li @click="jump(3)">儿童系列</li>
              </router-link>
              <router-link to="/product/4">
                <li @click="jump(4)">珍爱系列</li>
              </router-link>
              <router-link to="/product/5">
                <li @click="jump(5)">尊爱系列</li>
              </router-link>
              <router-link to="/product/6">
                <li @click="jump(6)">和风系列</li>
              </router-link>
            </ul>
            <em></em>
          </div>
        </li>
        <li class="footer_col txt_c" @click="jump(6)">
          和风软点
        </li>
        <li class="footer_col txt_c" @click="helpCenterShow">
            <i></i>
            帮助中心
          <div class="pfk kjia" style="left:276px" id="helpCenter" >
            <ul>
              <router-link to="javascript:;">
                <li>会员中心</li>
              </router-link>
              <router-link to="javascript:;">
                <li>门店列表</li>
              </router-link>
              <router-link to="javascript:;">
                <li>储值卡查询</li>
              </router-link>
            </ul>
            <em></em>
          </div>
        </li>
      </ul>
   </div>
        </div> 
    </div>
</template>
<style scoped>
*{
    padding: 0;
    margin: 0;
}
a{
    text-decoration: none;
    list-style: none;
    color:black;
}
    .lb_y{
        border-bottom: 56px solid transparent;
        overflow: hidden;
        min-height: 350px; 
    }
    .nav{
        padding: 10px 0;
        border-bottom: 1px solid #ccc;
    }
    .ui_tiled{
        display: -webkit-box;
        width: 100%;
    }
    .bg_fff {
        background: #fff;
    }
    .nav li {
        position: relative;
    }
    .ui_tiled li {
    -webkit-box-flex: 1;
    width: 100%;
    text-align: center;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-box-pack: center;
    -webkit-box-align: center;
    }
    .x_l{
    display: block;
    position: absolute;
    left: 49%;
    margin-left: -40%;
    width: 72%;
    background: #fff;
    top: 28px;
    display: none;
    padding: 0 10px;
    border: 1px solid #ccc;
    border-top: 0;
    margin-top: -1px;
    }
    .x_l p {
    display: block;
    text-align: center;
    line-height: 30px;
    border-bottom: 1px solid #ccc;
    }
    .p_x {
    display: block;
    position: absolute;
    right: 49%;
    margin-right: -40%;
    width: 72%;
    background: #fff;
    top: 28px;
    display: none;
    padding: 0 10px;
    border: 1px solid #ccc;
    border-top: 0;
    margin-top: -1px;
}
li .p_x a {
    display: block;
    text-align: center;
    line-height: 30px;
}
.nav li:after {
    content: "";
    display: inline-block;
    margin-left: 5px;
    width: 12px;
    height: 7px;
    background-position: -180px -13px;
    background: url(../assets/img/logo/ico_jt.png) no-repeat 0 -7px;
    background-size: 12px;
}
.cp_list{
    padding: 10px 10px 0 10px;
}
.cp_list li{
    float: left;
    width: 44%;
    padding: 0 10px;
    margin-bottom: 20px;
}
.box {
    background: #fff;
    margin: 0 auto;
    border: 1px solid #eaeaea;
}
.imgur {
    vertical-align: middle;
    text-align: center;
}
.imgur img {
    vertical-align: middle;
}
img{
    width: 100%;
    display:block;
}
.box .t {
    padding: 0 5px;
    line-height: 30px;
    height: 30px;
}
.nowrap {
    max-width: 100%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}
.box .j_g {
    padding: 0 5px;
    line-height: 27px;
    height: 27px;
    padding-bottom: 5px;
}
.c_blue {
    color: #2093cc;
}
.tj {
    float: right;
    background: url(../assets/img/logo/tjia-101.png) no-repeat center;
    background-size: 20px;
    width: 20px;
    height: 20px;
}
.footer{
  bottom: 0;
    height: 45px;
    position: fixed;
    width: 100%;
    z-index: 100;
    left: 0;
    background: #fafafa;
    border-top: 1px solid #dfdfdf;
}
.footer ul{
  height: 100%;
}
.row_flex{
   display: -webkit-box;
    width: 100%;
    -webkit-box-align: center;
}
.footer ul li{
   border-right: 1px solid #d0d0d0;
   height: 100%;
   line-height: 45px;
}
.txt_c{
  text-align: center !important;
}
.footer_col{
   padding: 1px;
   float: none;
   -webkit-box-flex: 1;
   width: 0;
}
.footer_col a{
  color: #626262;
}
.footer ul li i{
    display: inline-block;
    width: 12px;
    height: 12px;
    background: #bfbfbf;
    vertical-align: middle;
    margin-right: 10px;
    -webkit-border-radius: 20px;
    border-radius: 20px;
}
.footer ul li i:after{
    content: '';
    width: 50%;
    margin: 0 auto;
    height: 4px;
    border-bottom: 1px solid #fff;
    border-top: 1px solid #fff;
    display: block;
    margin-top: 4px;
}
.pfk{
    position: absolute;
    bottom: 55px; 
    left: 85px;
    background: #fff;
    width: 26%;
    /* border: 1px solid #ccc; */
    border-radius: 5px;
    display: none;
}
.pfk ul{
  height: auto;
}
.pfk li{
    padding: 0;
    margin: 0;
    height: 30px;
    line-height: 30px;
    border: 0;
    border-right: none !important;
    border-bottom: 1px solid #ccc;
    margin: 0 10px;
    position: relative;
    bottom: -1px;
}
.pfk em{
    display: block;
    border-width: 10px;
    position: absolute;
    bottom: -20px;
    border-style: solid dashed dashed;
    border-color: #fff transparent transparent;
    font-size: 0;
    line-height: 0;
    left: 50%;
    margin-left: -10px;
}
</style>
<script>
export default {
    data(){
        return{
           sortShow: false,
           helpShow: false,
           sortShow1:false,
           pShow:false,
           info:{}
        }
    },
    methods:{
    listShow(){
      let cakeSort = document.getElementById('cakeSort');
      let helpCenter = document.getElementById('helpCenter');
      if(!this.sortShow){
         cakeSort.style.display = "block";
         helpCenter.style.display = "none";
        this.helpShow = false;
         this.sortShow = true
      }else if(this.sortShow){
        cakeSort.style.display = "none";
        this.sortShow = false;
      }
    },
    helpCenterShow(){
      let cakeSort = document.getElementById('cakeSort');
      let helpCenter = document.getElementById('helpCenter');
      if(!this.helpShow){
         helpCenter.style.display = "block";
         cakeSort.style.display = "none";
         this.sortShow = false;
         this.helpShow = true
      }else if(this.helpShow){
        helpCenter.style.display = "none";
        this.helpShow = false;
      }
    },
    listShow1(){
      let cakeSort1 = document.getElementById('cakeSort1');
      let priceShow = document.getElementById('price');
      if(!this.sortShow1){
         cakeSort1.style.display = "block";
         priceShow.style.display = "none";
        this.pShow = false;
         this.sortShow1 = true
      }else if(this.sortShow1){
        cakeSort1.style.display = "none";
        this.sortShow1 = false;
      }
    },
    priceShow(){
        let priceShow = document.getElementById('price');
        let cakeSort1 = document.getElementById('cakeSort1');
      if(!this.pShow){
         priceShow.style.display = "block";
         cakeSort1.style.display = "none";
         this.sortShow1 = false;
         this.pShow = true
      }else if(this.pShow){
        priceShow.style.display = "none";
        this.pShow = false;
      }
    },
    jump(id){
      // console.log(id);
        this.axios.get('/product?family_id=' +id).then(res=>{
          this.info = res.data;
            let data = res.data;
            data.forEach(item=>{
              item.pic = require('../assets/img/list/'+item.pic)
            });
        })
    },
    /////////////////////
    all(){
      // this.$router.push('/product');
      this.axios.get('/product').then(res=>{
          this.info = res.data;
            let data = res.data;
            data.forEach(item=>{
              item.pic = require('../assets/img/list/'+item.pic)
            });
        })
    }
    },
    mounted(){
        let id = this.$route.params.family_id;
        let num = /^[0-9]$/
        if(num.test(id)){
          this.axios.get('/product?family_id=' +id).then(res=>{
            this.info = res.data;
            let data = res.data;
            data.forEach(item=>{
                item.pic = require('../assets/img/list/'+item.pic)
            });
        })
        }else{
          this.axios.get('/product?family_id=' +id).then(res=>{
            this.info = res.data;
            let data = res.data;
            data.forEach(item=>{
                item.pic = require('../assets/img/list/'+item.pic)
            });
        })
        }
    }
}
</script>