<template>
  <div>
    <!-- 顶部导航开始 -->
    <my-header></my-header>
    <!-- 顶部导航结束 -->
    <!-- 表单区域开始 -->
    <div>
        <mt-field 
          type="text" 
          label="电话号码"
          placeholder="请输入电话号码"
          :attr="{maxlength:15}"
          v-model="phone"
          :state="usernameState"
          @blur.native.capture="checkUsername">
        </mt-field>   

        <mt-field 
          type="password" 
          label="密码"
          placeholder="请输入密码"
          :attr="{maxlength:20,autocomplete:'off'}"
          v-model="upwd"
          :state="passwordState"
          @blur.native.capture="checkPassword">
        </mt-field>   

        <mt-field 
          type="password" 
          label="确认密码"
          placeholder="请再次输入密码"
          :attr="{maxlength:20,autocomplete:'off'}"
          v-model="conupwd"
          :state="conpasswordState"
          @blur.native.capture="checkConpassword">
        </mt-field>   

        <mt-button type="primary" size="large" @click="handle">免费注册</mt-button>    
    </div>
    <!-- 表单区域结束 -->
  </div>
</template>
<style scoped>
.shortcut{
  text-decoration: none;  
}
</style>
<script>
export default {
  data(){
    return {
      // 用户名
      phone:'',
      // 密码
      upwd:'',
      // 确认密码
      conupwd:'',
      // 用户名的状态
      usernameState:'',
      // 密码的状态
      passwordState:'',
      // 确认密码的状态
      conpasswordState:''
    }
  },
  methods:{
    //校验用户名
    checkUsername(){  
      let usernameRegExp = /^1[3-9]\d{9}$/;
      if(usernameRegExp.test(this.phone)){
        this.usernameState = 'success';
        return true;
      } else {
        this.usernameState = 'error';
        this.$toast({
          message:"电话号码为必填项",
          position:"top",
          duration:"2000"
        });
        return false;
      }
    },
    //校验密码
    checkPassword(){
      //密码的正则表达式
      let passwordRegExp = /^[0-9]{4,6}$/;
      if(passwordRegExp.test(this.upwd)){
        return true;
      } else {
        this.$toast({
          message:"密码为必填项",
          position:"top",
          duration:"2000"
        });
        return false;
      }
    },
    //校验确认密码
    checkConpassword(){
      if(this.upwd != this.conupwd){
        this.$toast({
          message:"两次密码不一致",
          position:"top",
          duration:"2000"
        });
        return false;
      } else {
        return true;
      }
    },
    handle(){
      if(this.checkUsername() && this.checkPassword() && this.checkConpassword()){
        //该将获取到的信息提交到WEB服务器
        this.axios.post('/register','phone='+this.phone+'&upwd='+this.upwd).then(res=>{
            //用户注册成功
            if(res.data.code == 1){
                this.$router.push('/login');
                this.$messagebox("注册提示","注册成功");
            } else{
                this.$messagebox('注册提示','用户名已经占用');
            }
        });
      }
    }
  }
}
</script>