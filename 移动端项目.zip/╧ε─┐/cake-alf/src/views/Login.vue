<template>
  <div>
    <!-- 顶部导航开始 -->
    <my-header></my-header>
    <!-- 顶部导航结束 -->
    <!-- 表单区域开始 -->
    <div>
        <mt-field 
          type="text" 
          label="电话号码"
          placeholder="请输入电话号码"
          :attr="{maxlength:15}"
          v-model="phone"
          :state="usernameState"
          @blur.native.capture="checkUsername">
        </mt-field>   

        <mt-field 
          type="password" 
          label="密码"
          placeholder="请输入密码"
          :attr="{maxlength:20,autocomplete:'off'}"
          v-model="upwd"
          :state="passwordState"
          @blur.native.capture="checkPassword">
        </mt-field>   


        <mt-button type="primary" size="large" @click="handle">快速登录</mt-button>    
    </div>
    <!-- 表单区域结束 -->
  </div>
</template>
<style scoped>
.shortcut{
  text-decoration: none;  
}
</style>
<script>
export default {
  data(){
    return {
      // 用户名
      phone:'',
      // 密码
      upwd:'',
      // 用户名的状态
      usernameState:'',
      // 密码的状态
      passwordState:''
    }
  },
  methods:{
    //校验用户名
    checkUsername(){  
      let usernameRegExp = /^1[3-9]\d{9}$/;
      if(usernameRegExp.test(this.phone)){
        this.usernameState = 'success';
        return true;
      } else {
        this.usernameState = 'error';
        this.$toast({
          message:"电话号码为必填项",
          position:"top",
          duration:"2000"
        });
        return false;
      }
    },
    //校验密码
    checkPassword(){
      //密码的正则表达式
      let passwordRegExp = /^[0-9]{4,6}$/;
      if(passwordRegExp.test(this.upwd)){
        return true;
      } else {
        this.$toast({
          message:"密码格式错误",
          position:"top",
          duration:"2000"
        });
        return false;
      }
    },   
    handle(){
      if(this.checkUsername() && this.checkPassword()){
        //该将获取到的信息提交到WEB服务器
        let obj = {
          phone:this.phone,
          upwd:this.upwd
        }
        console.log(obj);
        //派遣actions
        this.$store.dispatch('login',obj)
        // this.axios.post('/login',this.qs.stringify(obj)).then(res=>{
        //     //用户登录成功
        //     if(res.data.code == 1){
        //       //提交Mutations
        //       this.$store.commit('logined');
        //       //为什么还要往webstorage中存储呢?因为用户刷新后数据依然要保持
        //       localStorage.setItem('isLogined','1');
        //       this.$router.push('/');
        //     } else {
        //       this.$messagebox("登录提示","用户名或密码错误");
        //     }
        // })
      }
    }
  }
}
</script>